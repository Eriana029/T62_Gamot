#include <iostream>

using namespace std;

int main(){

    int n, k=1;
    cout << "Enter Any Positive Integer: ";
    cin >> n;

    while (n != 1){

        if (n%2 == 0)
            n = n/2;

        else
            n = n*3+1;

        cout << "\nCurrent Given Value is " << n;
        k++;
    }
    return 0;
}
